/*
 * bamlib.cpp
 *
 *  Created on: Mar 11, 2017
 *      Author: eliot
 */

#include "bamlib.hpp"
#include <seqan/sequence.h>
#include <seqan/bam_io.h>
#include <iterator>

using namespace seqan;


template<typename Out>
void split(const std::string &s, char delim, Out result) {
    std::stringstream ss;
    ss.str(s);
    std::string item;
    while (std::getline(ss, item, delim)) {
        *(result++) = item;
    }
}


std::vector<std::string> split(const std::string &s, char delim) {
    std::vector<std::string> elems;
    split(s, delim, std::back_inserter(elems));
    return elems;
}


template<typename TK, typename TV>
std::vector<TK> extract_keys(std::map<TK, TV> const& input_map) {
	std::vector<TK> retval;
	for (auto const& element : input_map) {
		retval.push_back(element.first);
	}
	return retval;
}


template<typename TK, typename TV>
std::vector<TV> extract_values(std::map<TK, TV> const& input_map) {
	std::vector<TV> retval;
	for (auto const& element : input_map) {
		retval.push_back(element.second);
	}
	return retval;
}

template<typename TK, typename TV>
std::map<TK, TV> build_mapq_histogram(std::string bamFileName) {

	//Open BamFileIn for reading.
	BamFileIn bamFileIn;

	if (!open(bamFileIn, toCString(bamFileName)))
	{
		std::cerr << "ERROR: Could not open " << bamFileName << " for reading.\n";
		return 1;
	}

	std::map<int, long> mapqHistogram;

	// Read records.
	BamAlignmentRecord record;
	while (!atEnd(bamFileIn))
	{
		readRecord(record, bamFileIn);
		int mapQ = record.mapQ;

		if (mapqHistogram.count(mapQ) == 0)
			mapqHistogram[mapQ] = 1;
		else
			mapqHistogram[mapQ] += 1;
	}

	return mapqHistogram;
}





int getTrainingFeatures(std::vector<unsigned char>& trainingData, int readLength, int nReads, bool noMultiMap, std::string bamFileName)
{
	std::string baiFileName = bamFileName + ".bai";
	std::string readSequence = "";

	std::map<std::string, int> chromosomeLengths;

	int readCounter = 0;

	//Open BamFileIn for reading.
	BamFileIn inFile;


//std::vector<std::string> x = split("SL2.50ch00_maternal-109031|-|18321202", '|');

//std::cout<<x[1]<<" "<<x[2]<<"\n";

//x = split("SL2.50ch00_maternal-109029|+|17175409", '|');

//std::cout<<x[1]<<" "<<x[2]<<"\n";

	if (!open(inFile, toCString(bamFileName)))
	{
		std::cerr << "ERROR: Could not open " << bamFileName << " for reading.\n";
		return 1;
	}

	// Read BAI index.
	BamIndex<Bai> baiIndex;
	if (!open(baiIndex, toCString(baiFileName)))
	{
		std::cerr << "ERROR: Could not read BAI index file " << baiFileName << "\n";
		return 1;
	}

	// Read header.
	BamHeader header;
	readHeader(header, inFile);

	typedef FormattedFileContext<BamFileIn, void>::Type TBamContext;

	TBamContext const & bamContext = context(inFile);

	for (unsigned i = 0; i < length(contigNames(bamContext)); ++i)
		chromosomeLengths[toCString(contigNames(bamContext)[i])] = contigLengths(bamContext)[i];

	for (unsigned i = 0; i < length(contigNames(bamContext)); ++i) {

		CharString rName = toCString(contigNames(bamContext)[i]);

		// Translate from reference name to rID.
		int rID = 0;
		if (!getIdByName(rID, contigNamesCache(context(inFile)), rName))
		{
			std::cerr << "ERROR: Reference sequence named " << rName << " not known.\n";
			return 1;
		}

		// Translate BEGIN and END arguments to number, 1-based to 0-based.
		int beginPos = 1, endPos = contigLengths(bamContext)[i];

		// 1-based to 0-based.
		beginPos -= 1;
		endPos -= 1;

		// Translate number of elements to print to number.
		int num = 3;

		// Jump the BGZF stream to this position.
		bool hasAlignments = false;
		if (!jumpToRegion(inFile, hasAlignments, rID, beginPos, endPos, baiIndex))
		{
			std::cerr << "ERROR: Could not jump to " << beginPos << ":" << endPos << "\n";
			return 1;
		}

		if (!hasAlignments)
			return 0;  // No alignments here.

		// Seek linearly to the selected position.
		BamAlignmentRecord record;

		int numMultiMaps = 0;

		std::cout << "Processing chromosome: "  << toCString(contigNames(bamContext)[i]) << "\n";

		while (!atEnd(inFile))
		{
			readRecord(record, inFile);


			unsigned tagIdx = 0;
			int tagValInt = 0;


			BamTagsDict tagsDict(record.tags);

			int primaryAlignmentScore = 0;
			int secondaryAlignmentScore = -75;

			if (!findTagKey(tagIdx, tagsDict, "XS"))
				extractTagValue(secondaryAlignmentScore, tagsDict, tagIdx);

			if (!findTagKey(tagIdx, tagsDict, "AS"))
				extractTagValue(primaryAlignmentScore, tagsDict, tagIdx);

			// If we are on the next reference or at the end already then we stop.
			if (record.rID == -1 || record.rID > rID || record.beginPos >= endPos)
				break;
			// If we are left of the selected position then we skip this record.
			if (record.beginPos < beginPos)
				continue;


			if (primaryAlignmentScore == secondaryAlignmentScore)
			{
				numMultiMaps++;
				continue;
			}



			readSequence = "";
			String<char> s = toCString(record.seq);
			if (i > 0){
			readCounter++;
			for (int k = 0;k < length(record.seq); ++k)
			{
				trainingData.push_back((unsigned char) s[k]);
			}
			}
			//trainingData.insert(trainingData.end(), readSequence.begin(), readSequence.end());


			if(readCounter == nReads)
				break;
		}

		if(readCounter == nReads)
			break;
	}

	return 0;
}


