/*
 * bamlib.hpp
 *
 *  Created on: Mar 11, 2017
 *      Author: eliot
 */


#include <string>
#include <zlib.h>
#include <pthread.h>
#include <iostream>
#include <stdio.h>
#include <ctype.h>
#include <vector>
#include <map>
#include <sstream>


void calc_invariants_cpu(const unsigned int height, const unsigned int width, float* matrix, const unsigned* dna_seqs);
int getTrainingFeatures(std::vector<unsigned char>& trainingData, int readLength, int nReads, bool noMultiMap, std::string bamFileName);





